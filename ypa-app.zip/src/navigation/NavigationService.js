import * as React from 'react';

export const navigationRef = React.createRef(); 
